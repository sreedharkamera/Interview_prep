package com.example.DependecyInjection;

public interface Computer {
void compile();
}

