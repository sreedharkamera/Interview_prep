package com.example.DependecyInjection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class DependecyInjectionApplication {

	public static void main(String[] args) {

		ConfigurableApplicationContext context=SpringApplication.run(DependecyInjectionApplication.class, args);

		Developer dev=context.getBean(Developer.class);
		dev.BuildCode();
	}

}
