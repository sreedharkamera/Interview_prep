package com.example.DependecyInjection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
public class Developer {

    //field injection
//    @Autowired
//    @Qualifier("Desktop11")
    private Computer computer;

    @Autowired
    Developer(@Qualifier("Desktop11") Computer computer){
        this.computer=computer;
    }
//
//    @Autowired
//    public void setterlaptop(Laptop laptop){
//        this.laptop=laptop;
//    }

    public void BuildCode(){
        System.out.println("Can build the code");
        computer.compile();
    }
}
