package com.example.DependecyInjection;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("Laptop11")
@Primary
public class Laptop implements Computer {
    public void compile(){
        System.out.println("Priting of laptop compile");
    }
}
