package com.example.DependecyInjection;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DependecyInjectionApplicationTests {

	@Test
	void contextLoads() {
	}

}
