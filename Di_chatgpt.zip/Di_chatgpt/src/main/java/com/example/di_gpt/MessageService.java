package com.example.di_gpt;

public interface MessageService {
	
	public void sendmessage(String Message);	

}

class EmailService implements MessageService{
	public void sendmessage(String Message)
	{
	
		System.out.println("Email sent: "+Message);
	}
}
class smsService implements MessageService{
	public void sendmessage(String Message)
	{
		System.out.println("SMS sent: "+Message);
	}
}