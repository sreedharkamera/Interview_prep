package com.example.di_gpt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotificationService {

	public MessageService messageService;
	
	public NotificationService(MessageService messageService) {
		this.messageService=messageService;
	}
	void notifyuser(String message)
	{
		messageService.sendmessage(message);
	}
	public static void main(String[] args) {
		//SpringApplication.run(DiChatgptApplication.class, args);
		MessageService emailservice=                      new EmailService();
		NotificationService notification =new NotificationService(emailservice);
		notification.notifyuser("Hello,its from email service");
	}

	
}
