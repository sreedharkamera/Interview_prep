package com.example.SimpleWebapp.controller;

import com.example.SimpleWebapp.model.Product;
import com.example.SimpleWebapp.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductController {

    @Autowired
    ProductService productService;

    @RequestMapping("/getproducts")
    @ResponseBody
    public List<Product> getProducts(){
        return productService.getProducts();
    }

    @RequestMapping("/getproducts/{prodid}")
    public Product getproductvyId(@PathVariable int prodid){
        System.out.println("Inside prodid na==mapping");
        return productService.getproductvyId(prodid);
    }

    @PostMapping("/InsertProduct")
    public void addproduct(@RequestBody Product prod)
    {
        System.out.println("Inside UpdateProduct");
        productService.addProduct(prod);
    }
    @PutMapping("/UpdateProduct")
    public void updateproduct(@RequestBody Product prod){
        productService.updateproduct(prod);
    }
    @DeleteMapping("/Deleteproduct/{prodid}")
    public void deleteproduct(@PathVariable int prodid)
    {
        productService.deleteproduct(prodid);
    }
}
