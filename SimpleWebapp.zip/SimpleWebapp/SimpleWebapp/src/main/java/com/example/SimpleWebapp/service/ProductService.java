package com.example.SimpleWebapp.service;

import com.example.SimpleWebapp.model.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
@Service
public class ProductService {
    List<Product> products = new ArrayList<>(Arrays.asList(
            new Product(101, "Iphone", 5000),
            new Product(102, "Oneplus", 7000),
            new Product(103, "Samsung", 1000)));

    public List<Product> getProducts() {
        return products;

    }

    public Product getproductvyId(int prodid) {
        return products.stream()
                .filter(p -> p.getProdID() == prodid)
                .findFirst().orElse(new Product(104, "vivo", 4000));
    }

    public void addProduct(Product prod) {
        products.add(prod);
    }

    public void updateproduct(Product prod) {
        int index = 0;
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getProdID() == prod.getProdID()) {
                index = i;
                products.set(index, prod);
            }
        }
    }

    public void deleteproduct(int prodid) {
        int index = 0;
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getProdID() == prodid) {
                index = i;
                products.remove(index);
            }

        }
    }
}
