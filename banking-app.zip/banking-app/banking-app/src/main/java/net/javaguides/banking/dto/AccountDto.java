package net.javaguides.banking.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@AllArgsConstructor
//above generates constrcutors
public class AccountDto {
    private Long id;
    private String accountHolderName;
    private double balence;
}
