package net.javaguides.banking.service.impl;

import net.javaguides.banking.dto.AccountDto;
import net.javaguides.banking.entity.Account;
import net.javaguides.banking.mapper.AccountMapper;
import net.javaguides.banking.repository.AccountRepository;
import net.javaguides.banking.service.AccountService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
//creates springbean for this class by using @service
public class AccountServiceImpl implements AccountService {

    //inject dependency
    private AccountRepository  accountRepository;

    public AccountServiceImpl(AccountRepository accountRepository)
    {
        this.accountRepository=accountRepository;
    }

    @Override
    public AccountDto createAccount(AccountDto accountDto) {
        Account account= AccountMapper.maptoAccount(accountDto);
        Account savedAccount=accountRepository.save(account);
        return AccountMapper.mapToAccountDto(savedAccount);
        //accountdto to accountjpaentity and share accountjpaentiy to database

    }
    @Override
    public AccountDto getAccountById(Long id){
        Account account=accountRepository.
                findById(id).
                orElseThrow(()->new RuntimeException("account doesnt exist"));

        AccountDto accountDto=AccountMapper.mapToAccountDto(account);
        return accountDto;


    }

    @Override
    public AccountDto deposit(Long id, double amount) {
        Account account=accountRepository.
                findById(id).
                orElseThrow(()->new RuntimeException("account doesnt exist"));
        double total=account.getBalence() + amount;
        account.setBalence(total);
        Account savedaccount=accountRepository.save(account);
        return AccountMapper.mapToAccountDto(savedaccount);
    }

    @Override
    public AccountDto withdraw(Long id, double amount) {
        //account is exist or not throw exception
        Account account=accountRepository.
                findById(id).
                orElseThrow(()->new RuntimeException("account doesnt exist"));

        if(account.getBalence()<amount)
        {
            throw new RuntimeException("Insuffient amount");
        }

        double total=account.getBalence() - amount;
        account.setBalence(total);
        Account savedaccount=accountRepository.save(account);
        return AccountMapper.mapToAccountDto(savedaccount);


    }

    @Override
    public List<AccountDto> getAllAccounts() {
        List<Account> accounts=accountRepository.findAll();
        return accounts.stream().map((account) -> AccountMapper.mapToAccountDto(account))
                .collect(Collectors.toList());
    }

    @Override
    public void deleteAccount(Long id) {
        Account account=accountRepository
                .findById(id).
                orElseThrow(()->new RuntimeException("account doesnt exist"));
        accountRepository.deleteById(id);
    }

}
